﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeatherApp.Model;

namespace WeatherApp.Business
{
    class Core
    {

        public static async Task<WeatherDetails> GetWeather(string zipCode)
        {
            //Sign up for a free API key at http://openweathermap.org/appid
            string key = "6873e1518f0153754b6c7555f26e5768";

            string queryString = "http://api.openweathermap.org/data/2.5/weather?zip="
                + zipCode + "&appid=" + key;

            //{"coord":{"lon":-74,"lat":40.75},"weather":[{"id":800,"main":"Clear","description":"clear sky","icon":"01n"}],"base":"stations","main":{"temp":283.3,"pressure":1025,"humidity":53,"temp_min":281.15,"temp_max":285.15},"visibility":16093,"wind":{"speed":4.1,"deg":340,"gust":7.7},"clouds":{"all":1},"dt":1509771360,"sys":{"type":1,"id":2121,"message":0.0106,"country":"US","sunrise":1509795025,"sunset":1509832089},"id":0,"name":"New York","cod":200}
            var results = await DataService.getDataFromService(queryString).ConfigureAwait(false);

            

            if (results["weather"] != null)
            {
                WeatherDetails weatherDetails = new WeatherDetails();
                weatherDetails.name = (string)results["name"];
                weatherDetails.temprature = (string)results["main"]["temp"] + " F";
                //MainPage weather = new MainPage();
                //weather.Title = (string)results["name"];
                //weather.Temperature = (string)results["main"]["temp"] + " F";
                //weather.Wind = (string)results["wind"]["speed"] + " mph";
                //weather.Humidity = (string)results["main"]["humidity"] + " %";
                //weather.Visibility = (string)results["weather"][0]["main"];

                //DateTime time = new System.DateTime(1970, 1, 1, 0, 0, 0, 0);
                //DateTime sunrise = time.AddSeconds((double)results["sys"]["sunrise"]);
                //DateTime sunset = time.AddSeconds((double)results["sys"]["sunset"]);
                //weather.Sunrise = sunrise.ToString() + " UTC";
                //weather.Sunset = sunset.ToString() + " UTC";
                return weatherDetails;
            }
            else
            {
                return null;
            }
        }
    }
}
