﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace WeatherApp.Business
{
    internal class DataService
    {
        public static async Task<JContainer> getDataFromService(string queryString)
        {
            HttpClient client = new HttpClient();
             var response = await client.GetStringAsync(queryString);

            JContainer data = null;
            if (response != null)
            {
                //string json = response.Content.ReadAsStringAsync().Result;
                data = (JContainer)JsonConvert.DeserializeObject(response);
            }

            return data;
        }
    }
}