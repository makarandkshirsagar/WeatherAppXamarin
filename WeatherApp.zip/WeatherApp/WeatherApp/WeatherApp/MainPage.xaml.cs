﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WeatherApp.Business;
using WeatherApp.Model;
using Xamarin.Forms;

namespace WeatherApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void BtnXml_Click1(object sender, EventArgs e)
        {
            var mainPage = new XmlParsingPage();//this could be content page
            var rootPage = new NavigationPage(mainPage);
            App.Navigation = rootPage.Navigation;
            //Navigation.PushAsync(new XmlParsingPage());
        }

        private async void BtnXml_Click(object sender, EventArgs e)
        {
            WeatherDetails weather = await Core.GetWeather("10001");

            //var mainPage = new WeatherDisplay(weather);//this could be content page
            //var rootPage = new NavigationPage(mainPage);
            //App.Navigation = rootPage.Navigation;

            //lblTitle.BindingContext = weather.name;
            //await DisplayAlert("Weather Information", "Location Name "+weather.name, "OK");

            //if (weather != null)
            //{
            //    this.BindingContext = weather;
            //    //getWeatherBtn.Text = "Search Again";
            //}
        }
    }
}
