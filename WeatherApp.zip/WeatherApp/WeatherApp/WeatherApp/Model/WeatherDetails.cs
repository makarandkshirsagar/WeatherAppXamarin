﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherApp.Model
{
    public class WeatherDetails
    {
        public string name { get; set; }
        public string temprature { get; set; }
    }
}
