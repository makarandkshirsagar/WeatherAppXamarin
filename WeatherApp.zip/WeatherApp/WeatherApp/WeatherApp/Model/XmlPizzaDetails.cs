﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherApp.Model
{
    class XmlPizzaDetails
    {
        public string id { get; set; }
        public string name { get; set; }
        public string cost { get; set; }
        public string description { get; set; }
    }
}
